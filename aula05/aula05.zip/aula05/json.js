// json pronto para desafio
module.exports = `[
  {
      "nome": "Costelinha",
      "tipo": "cachorro",
      "raca": "Dálmata",
      "idade": 6,
      "genero": "Masculino"
  },
  {
      "nome": "Kiara",
      "tipo": "cachorro",
      "raca": "American Bully",
      "idade": 2,
      "genero": "Fêmea"
  },
  {
      "nome": "Onix",
      "tipo": "cachorro",
      "raca": "Rotweiller",
      "idade": 8,
      "genero": "Masculino"
  },
  {
      "nome": "Spike",
      "tipo": "gato",
      "raca": "Siamês",
      "idade": 2,
      "genero": "Masculino"
  },
  {
      "nome": "Coralina",
      "tipo": "gato",
      "raca": "Siamês",
      "idade": 2,
      "genero": "Fêmea"
  }
]`