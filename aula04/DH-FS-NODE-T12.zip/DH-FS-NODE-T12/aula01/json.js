// json pronto para desafio
let dia = "05/10/2020"
let x = "1"
module.exports = {
  dia
}